import React from 'react';
export default function Assignments() {
  return <div className="p-4">Assignments - Coming Soon</div>;
}
