import React from 'react';
export default function Transfers() {
  return <div className="p-4">Transfers - Coming Soon</div>;
}
