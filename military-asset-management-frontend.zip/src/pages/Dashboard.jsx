import React from 'react';
export default function Dashboard() {
  return <div className="p-4">Dashboard - Coming Soon</div>;
}
