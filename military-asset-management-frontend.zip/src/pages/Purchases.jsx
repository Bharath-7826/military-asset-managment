import React from 'react';
export default function Purchases() {
  return <div className="p-4">Purchases - Coming Soon</div>;
}
